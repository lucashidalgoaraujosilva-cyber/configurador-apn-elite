export interface CarrierData {
  name: string;
  apn: string;
  dial: string;
  color: number;
}

export interface BrandGuide {
  label: string;
  lines: string[];
  apn: string[];
  manual: string[];
}

export const CARRIERS: Record<string, CarrierData> = {
  telecall: {
    name: "abcrede",
    apn: "abcrede",
    dial: "0 + DDD + Número",
    color: 220
  },
  americanet: {
    name: "abcRede",
    apn: "a85",
    dial: "0 + 85 + DDD + Número",
    color: 265
  },
  bora: {
    name: "BORA.COM",
    apn: "BORA.COM",
    dial: "0 + DDD + Número",
    color: 25
  }
};

export const BRANDS: Record<string, BrandGuide> = {
  xiaomi: {
    label: "Xiaomi (MIUI)",
    lines: ["Linha Redmi Note", "Linha Redmi (Entrada)", "Linha Poco", "Linha Mi / Xiaomi"],
    apn: [
      "Abra as <strong>Configurações</strong> (ícone de engrenagem).",
      "Toque na opção <strong>Cartões SIM e redes móveis</strong>.",
      "Selecione o <strong>Chip da Operadora</strong> (pode estar como SIM 1 ou SIM 2).",
      "Procure e toque em <strong>Nomes dos pontos de acesso</strong> (ou APN).",
      "Na barra inferior, toque no sinal de <strong>+</strong> (Nova APN).",
      "Preencha o campo <strong>Nome</strong> com o valor indicado acima.",
      "Preencha o campo <strong>APN</strong> com o valor indicado acima.",
      "Toque no botão <strong>Mais</strong> (ou 3 pontinhos na parte inferior) e selecione <strong>Salvar</strong>."
    ],
    manual: [
      "Vá em <strong>Configurações</strong> > <strong>Cartões SIM e redes móveis</strong>.",
      "Selecione o <strong>Chip da Operadora</strong>.",
      "Toque em <strong>Redes móveis</strong>.",
      "Desative a chave <strong>Selecionar rede automaticamente</strong>.",
      "Aguarde a busca terminar e selecione a operadora correspondente na lista."
    ]
  },
  samsung: {
    label: "Samsung Galaxy",
    lines: ["Linha Galaxy S", "Linha Galaxy A", "Linha Galaxy M", "Linha Z / Note"],
    apn: [
      "Abra as <strong>Configurações</strong> e toque em <strong>Conexões</strong>.",
      "Toque em <strong>Redes móveis</strong>.",
      "Selecione a opção <strong>Pontos de acesso</strong>.",
      "No canto superior direito, toque em <strong>Adicionar</strong>.",
      "Preencha o <strong>Nome</strong> e a <strong>APN</strong> com os dados acima.",
      "Toque nos <strong>3 pontinhos</strong> (canto superior direito) e selecione <strong>Salvar</strong>."
    ],
    manual: [
      "Vá em <strong>Configurações</strong> > <strong>Conexões</strong>.",
      "Toque em <strong>Redes móveis</strong>.",
      "Toque em <strong>Operadores de rede</strong> (ou Configuração de rede).",
      "Selecione <strong>Procurar redes</strong> ou desative 'Selecionar automaticamente'.",
      "Selecione a rede correta na lista apresentada."
    ]
  },
  motorola: {
    label: "Motorola",
    lines: ["Linha Moto G", "Linha Motorola Edge", "Linha Moto E", "Linha One"],
    apn: [
      "Acesse o menu <strong>Configurar</strong>.",
      "Toque em <strong>Rede e internet</strong> e depois em <strong>Rede móvel</strong>.",
      "Toque em <strong>Avançado</strong> para expandir as opções.",
      "Selecione <strong>Nomes dos pontos de acesso</strong>.",
      "Toque no sinal de <strong>+</strong> no canto superior direito.",
      "Preencha o Nome e a APN. Depois, toque nos 3 pontinhos e clique em <strong>Salvar</strong>."
    ],
    manual: [
      "Vá em <strong>Configurar</strong> > <strong>Rede e internet</strong>.",
      "Toque em <strong>Rede móvel</strong> > <strong>Avançado</strong>.",
      "Desmarque a opção <strong>Selecionar rede automaticamente</strong>.",
      "Aguarde o celular encontrar as antenas e selecione sua operadora."
    ]
  },
  iphone: {
    label: "Apple iPhone",
    lines: ["Todos os Modelos (iOS 15+)", "Modelos Antigos (iOS 14-)", "iPad (Cellular)"],
    apn: [
      "Abra os <strong>Ajustes</strong>.",
      "Toque em <strong>Celular</strong> (ou Dados Móveis).",
      "Selecione <strong>Rede de Dados Celulares</strong>.",
      "Nos campos da seção 'DADOS CELULARES', preencha a <strong>APN</strong> com o dado acima.",
      "Não é necessário preencher usuário ou senha.",
      "Toque em <strong>< Voltar</strong> ou <strong>< Celular</strong> para salvar automaticamente."
    ],
    manual: [
      "Vá em <strong>Ajustes</strong> > <strong>Celular</strong>.",
      "Toque em <strong>Seleção de Rede</strong>.",
      "Desative a chave <strong>Automática</strong>.",
      "O iPhone vai buscar as redes. Selecione a sua operadora na lista."
    ]
  },
  lg: {
    label: "LG",
    lines: ["Linha K", "Linha Velvet / G"],
    apn: [
      "Acesse <strong>Ajustes</strong> e vá na aba <strong>Rede</strong>.",
      "Toque em <strong>Redes móveis</strong>.",
      "Vá em <strong>Pontos de acesso (APN)</strong>.",
      "Toque no menu (3 pontinhos) e selecione <strong>Novo APN</strong>.",
      "Insira os dados de Nome e APN e toque em Salvar."
    ],
    manual: [
      "Acesse <strong>Ajustes</strong> > <strong>Redes móveis</strong>.",
      "Toque em <strong>Operadores de Rede</strong>.",
      "Toque em <strong>Pesquisar redes</strong>.",
      "Selecione a operadora manualmente na lista."
    ]
  }
};
